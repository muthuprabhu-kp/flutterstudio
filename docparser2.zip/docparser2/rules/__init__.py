from rules.rule1 import Rule1


def get_rules():
    yield Rule1()
