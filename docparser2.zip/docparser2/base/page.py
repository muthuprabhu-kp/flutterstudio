class Page(object):
    def __init__(self, page):
        self.page = page

    def get_paragraph(self):
        pass
